-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Agu 2020 pada 15.23
-- Versi server: 10.4.13-MariaDB
-- Versi PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perdin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `biaya_fasilitas_pangkat`
--

CREATE TABLE `biaya_fasilitas_pangkat` (
  `id_biaya` varchar(15) NOT NULL,
  `id_fasilitas` varchar(15) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_pangkat` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `biaya_fasilitas_pangkat`
--

INSERT INTO `biaya_fasilitas_pangkat` (`id_biaya`, `id_fasilitas`, `harga`, `id_pangkat`) VALUES
('B001', 'IDF001', 300000, 'PK001'),
('B002', 'IDF001', 150000, 'PK002'),
('B003', 'IDF002', 500000, 'PK001'),
('B004', 'IDF002', 350000, 'PK002'),
('B005', 'IDF003', 250000, 'PK001'),
('B006', 'IDF003', 185000, 'PK002'),
('B007', 'IDF004', 450000, 'PK001'),
('B008', 'IDF004', 250000, 'PK002'),
('B009', 'IDF005', 250000, 'PK001'),
('B010', 'IDF005', 200000, 'PK002'),
('B011', 'IDF006', 400000, 'PK001'),
('B012', 'IDF006', 300000, 'PK002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `divisi`
--

CREATE TABLE `divisi` (
  `id_divisi` varchar(15) NOT NULL,
  `nama_divisi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `divisi`
--

INSERT INTO `divisi` (`id_divisi`, `nama_divisi`) VALUES
('DV001', 'Teknologi Informasi dan Pengembangan Produk'),
('DV002', 'Jaringan Telekominikasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasilitas`
--

CREATE TABLE `fasilitas` (
  `id_fasilitas` varchar(15) NOT NULL,
  `id_provinsi` varchar(15) NOT NULL,
  `id_jenis_fasilitas` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `fasilitas`
--

INSERT INTO `fasilitas` (`id_fasilitas`, `id_provinsi`, `id_jenis_fasilitas`) VALUES
('IDF001', 'PROV001', 'JF001'),
('IDF002', 'PROV001', 'JF002'),
('IDF003', 'PROV002', 'JF001'),
('IDF004', 'PROV002', 'JF002'),
('IDF005', 'PROV003', 'JF001'),
('IDF006', 'PROV003', 'JF002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasilitas_perdin`
--

CREATE TABLE `fasilitas_perdin` (
  `id_perdin` varchar(50) NOT NULL,
  `id_biaya` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `fasilitas_perdin`
--

INSERT INTO `fasilitas_perdin` (`id_perdin`, `id_biaya`) VALUES
('17111055/2020821202059', 'B002'),
('17111055/2020821202059', 'B004'),
('17111050/2020821201428', 'B009'),
('17111050/2020821201428', 'B011');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` varchar(15) NOT NULL,
  `nama_jabatan` varchar(50) NOT NULL,
  `tingkat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`, `tingkat`) VALUES
('J001', 'Officer Teknologi Informasi', 6),
('J002', 'Sekertaris', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_fasilitas`
--

CREATE TABLE `jenis_fasilitas` (
  `id_jenis_fasilitas` varchar(15) NOT NULL,
  `nama_fasilitas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jenis_fasilitas`
--

INSERT INTO `jenis_fasilitas` (`id_jenis_fasilitas`, `nama_fasilitas`) VALUES
('JF001', 'Uang Harian'),
('JF002', 'Uang Penginapan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `nip` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `id_pangkat` varchar(15) NOT NULL,
  `id_jabatan` varchar(15) NOT NULL,
  `id_divisi` varchar(15) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`nip`, `nama`, `id_pangkat`, `id_jabatan`, `id_divisi`, `username`, `password`) VALUES
('17111050', 'Ikhsan Alfath', 'PK001', 'J001', 'DV001', 'ikhsanalfath', 'ikhsan99'),
('17111055', 'Indra Kusnadi', 'PK002', 'J002', 'DV002', 'indrakusnadi', 'indra97');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kota`
--

CREATE TABLE `kota` (
  `id_kota` varchar(15) NOT NULL,
  `nama_kota` varchar(50) NOT NULL,
  `id_provinsi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kota`
--

INSERT INTO `kota` (`id_kota`, `nama_kota`, `id_provinsi`) VALUES
('KT001', 'Bandung', 'PROV001'),
('KT002', 'Yogyakarta', 'PROV002'),
('KT003', 'Surabaya', 'PROV003');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pangkat`
--

CREATE TABLE `pangkat` (
  `id_pangkat` varchar(15) NOT NULL,
  `nama_pangkat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pangkat`
--

INSERT INTO `pangkat` (`id_pangkat`, `nama_pangkat`) VALUES
('PK001', 'Manager'),
('PK002', 'Officer');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perdin`
--

CREATE TABLE `perdin` (
  `id_perdin` varchar(50) NOT NULL,
  `nip` varchar(15) NOT NULL,
  `jenis_perdin` enum('Dalam Kota','Luar Kota','Dalam Negri Direksi') NOT NULL,
  `tujuan_keberangkatan` varchar(50) NOT NULL,
  `transportasi` enum('Kereta','Pesawat','Mobil','Kapal') NOT NULL,
  `kota_asal` varchar(15) NOT NULL,
  `kota_tujuan` varchar(15) NOT NULL,
  `tgl_berangkat` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `pengajuan` enum('Pengajuan Perjalanan','Realisasi Langsung') NOT NULL,
  `jenis_pekerjaan` varchar(50) NOT NULL,
  `akomodasi` enum('Tidak Lumpsum','Lumpsum') NOT NULL,
  `total_biaya_ajuan` int(11) NOT NULL,
  `total_biaya_realisasi` int(11) NOT NULL,
  `lama_perjalanan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `perdin`
--

INSERT INTO `perdin` (`id_perdin`, `nip`, `jenis_perdin`, `tujuan_keberangkatan`, `transportasi`, `kota_asal`, `kota_tujuan`, `tgl_berangkat`, `tgl_kembali`, `pengajuan`, `jenis_pekerjaan`, `akomodasi`, `total_biaya_ajuan`, `total_biaya_realisasi`, `lama_perjalanan`) VALUES
('17111050/2020821201428', '17111050', 'Dalam Kota', 'Observasi', 'Mobil', 'KT001', 'KT003', '2020-09-07', '2020-09-09', 'Pengajuan Perjalanan', 'Dinas', 'Tidak Lumpsum', 650000, 4000000, 2),
('17111055/2020821202059', '17111055', 'Dalam Kota', 'Meeting', 'Pesawat', 'KT002', 'KT001', '2020-08-06', '2020-08-08', 'Pengajuan Perjalanan', 'Dinas', 'Tidak Lumpsum', 500000, 4000000, 2);

--
-- Trigger `perdin`
--
DELIMITER $$
CREATE TRIGGER `hapus_perdin` BEFORE DELETE ON `perdin` FOR EACH ROW DELETE FROM fasilitas_perdin 
WHERE id_perdin = id_perdin
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `provinsi`
--

CREATE TABLE `provinsi` (
  `id_provinsi` varchar(15) NOT NULL,
  `nama_provinsi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `provinsi`
--

INSERT INTO `provinsi` (`id_provinsi`, `nama_provinsi`) VALUES
('PROV001', 'Jawa Barat'),
('PROV002', 'Jawa Tengah'),
('PROV003', 'Jawa Timur');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_biaya_fasilitas`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_biaya_fasilitas` (
`id_biaya` varchar(15)
,`nama_fasilitas` varchar(50)
,`id_provinsi` varchar(15)
,`nama_provinsi` varchar(50)
,`id_pangkat` varchar(15)
,`nama_pangkat` varchar(50)
,`harga` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_fasilitas`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_fasilitas` (
`id_fasilitas` varchar(15)
,`nama_provinsi` varchar(50)
,`nama_fasilitas` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_fasilitas_perdin`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_fasilitas_perdin` (
`id_perdin` varchar(50)
,`nama_fasilitas` varchar(50)
,`harga` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `view_kota_provinsi`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `view_kota_provinsi` (
`id_kota` varchar(15)
,`nama_kota` varchar(50)
,`id_provinsi` varchar(15)
,`nama_provinsi` varchar(50)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `view_biaya_fasilitas`
--
DROP TABLE IF EXISTS `view_biaya_fasilitas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_biaya_fasilitas`  AS  select `biaya_fasilitas_pangkat`.`id_biaya` AS `id_biaya`,`jenis_fasilitas`.`nama_fasilitas` AS `nama_fasilitas`,`provinsi`.`id_provinsi` AS `id_provinsi`,`provinsi`.`nama_provinsi` AS `nama_provinsi`,`pangkat`.`id_pangkat` AS `id_pangkat`,`pangkat`.`nama_pangkat` AS `nama_pangkat`,`biaya_fasilitas_pangkat`.`harga` AS `harga` from ((((`biaya_fasilitas_pangkat` join `pangkat` on(`biaya_fasilitas_pangkat`.`id_pangkat` = `pangkat`.`id_pangkat`)) join `fasilitas` on(`fasilitas`.`id_fasilitas` = `biaya_fasilitas_pangkat`.`id_fasilitas`)) join `provinsi` on(`provinsi`.`id_provinsi` = `fasilitas`.`id_provinsi`)) join `jenis_fasilitas` on(`jenis_fasilitas`.`id_jenis_fasilitas` = `fasilitas`.`id_jenis_fasilitas`)) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_fasilitas`
--
DROP TABLE IF EXISTS `view_fasilitas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_fasilitas`  AS  select `fasilitas`.`id_fasilitas` AS `id_fasilitas`,`provinsi`.`nama_provinsi` AS `nama_provinsi`,`jenis_fasilitas`.`nama_fasilitas` AS `nama_fasilitas` from ((`fasilitas` join `provinsi` on(`provinsi`.`id_provinsi` = `fasilitas`.`id_provinsi`)) join `jenis_fasilitas` on(`jenis_fasilitas`.`id_jenis_fasilitas` = `fasilitas`.`id_jenis_fasilitas`)) order by `provinsi`.`nama_provinsi` ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_fasilitas_perdin`
--
DROP TABLE IF EXISTS `view_fasilitas_perdin`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_fasilitas_perdin`  AS  select `perdin`.`id_perdin` AS `id_perdin`,`jenis_fasilitas`.`nama_fasilitas` AS `nama_fasilitas`,`biaya_fasilitas_pangkat`.`harga` AS `harga` from ((((((`perdin` join `fasilitas_perdin` on(`fasilitas_perdin`.`id_perdin` = `perdin`.`id_perdin`)) join `biaya_fasilitas_pangkat` on(`biaya_fasilitas_pangkat`.`id_biaya` = `fasilitas_perdin`.`id_biaya`)) join `pangkat` on(`pangkat`.`id_pangkat` = `biaya_fasilitas_pangkat`.`id_pangkat`)) join `fasilitas` on(`fasilitas`.`id_fasilitas` = `biaya_fasilitas_pangkat`.`id_fasilitas`)) join `jenis_fasilitas` on(`jenis_fasilitas`.`id_jenis_fasilitas` = `fasilitas`.`id_jenis_fasilitas`)) join `provinsi` on(`provinsi`.`id_provinsi` = `fasilitas`.`id_provinsi`)) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `view_kota_provinsi`
--
DROP TABLE IF EXISTS `view_kota_provinsi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_kota_provinsi`  AS  select `kota`.`id_kota` AS `id_kota`,`kota`.`nama_kota` AS `nama_kota`,`provinsi`.`id_provinsi` AS `id_provinsi`,`provinsi`.`nama_provinsi` AS `nama_provinsi` from (`kota` join `provinsi`) where `kota`.`id_provinsi` = `provinsi`.`id_provinsi` ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `biaya_fasilitas_pangkat`
--
ALTER TABLE `biaya_fasilitas_pangkat`
  ADD PRIMARY KEY (`id_biaya`),
  ADD KEY `id_fasilitas` (`id_fasilitas`),
  ADD KEY `id_pangkat` (`id_pangkat`);

--
-- Indeks untuk tabel `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`id_divisi`);

--
-- Indeks untuk tabel `fasilitas`
--
ALTER TABLE `fasilitas`
  ADD PRIMARY KEY (`id_fasilitas`),
  ADD KEY `id_provinsi` (`id_provinsi`,`id_jenis_fasilitas`),
  ADD KEY `id_jenis_fasilitas` (`id_jenis_fasilitas`);

--
-- Indeks untuk tabel `fasilitas_perdin`
--
ALTER TABLE `fasilitas_perdin`
  ADD KEY `id_harga_fasilitas` (`id_biaya`,`id_perdin`),
  ADD KEY `id_perdin` (`id_perdin`);

--
-- Indeks untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indeks untuk tabel `jenis_fasilitas`
--
ALTER TABLE `jenis_fasilitas`
  ADD PRIMARY KEY (`id_jenis_fasilitas`);

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `id_pangkat` (`id_pangkat`),
  ADD KEY `id_jabatan` (`id_jabatan`),
  ADD KEY `id_divisi` (`id_divisi`);

--
-- Indeks untuk tabel `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`id_kota`),
  ADD KEY `id_provinsi` (`id_provinsi`);

--
-- Indeks untuk tabel `pangkat`
--
ALTER TABLE `pangkat`
  ADD PRIMARY KEY (`id_pangkat`);

--
-- Indeks untuk tabel `perdin`
--
ALTER TABLE `perdin`
  ADD PRIMARY KEY (`id_perdin`),
  ADD KEY `nip` (`nip`),
  ADD KEY `kota_asal` (`kota_asal`,`kota_tujuan`),
  ADD KEY `kota_tujuan` (`kota_tujuan`);

--
-- Indeks untuk tabel `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`id_provinsi`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `biaya_fasilitas_pangkat`
--
ALTER TABLE `biaya_fasilitas_pangkat`
  ADD CONSTRAINT `biaya_fasilitas_pangkat_ibfk_1` FOREIGN KEY (`id_fasilitas`) REFERENCES `fasilitas` (`id_fasilitas`),
  ADD CONSTRAINT `biaya_fasilitas_pangkat_ibfk_2` FOREIGN KEY (`id_pangkat`) REFERENCES `pangkat` (`id_pangkat`);

--
-- Ketidakleluasaan untuk tabel `fasilitas`
--
ALTER TABLE `fasilitas`
  ADD CONSTRAINT `fasilitas_ibfk_1` FOREIGN KEY (`id_provinsi`) REFERENCES `provinsi` (`id_provinsi`),
  ADD CONSTRAINT `fasilitas_ibfk_2` FOREIGN KEY (`id_jenis_fasilitas`) REFERENCES `jenis_fasilitas` (`id_jenis_fasilitas`);

--
-- Ketidakleluasaan untuk tabel `fasilitas_perdin`
--
ALTER TABLE `fasilitas_perdin`
  ADD CONSTRAINT `fasilitas_perdin_ibfk_1` FOREIGN KEY (`id_biaya`) REFERENCES `biaya_fasilitas_pangkat` (`id_biaya`),
  ADD CONSTRAINT `fasilitas_perdin_ibfk_2` FOREIGN KEY (`id_perdin`) REFERENCES `perdin` (`id_perdin`);

--
-- Ketidakleluasaan untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `karyawan_ibfk_1` FOREIGN KEY (`id_pangkat`) REFERENCES `pangkat` (`id_pangkat`),
  ADD CONSTRAINT `karyawan_ibfk_2` FOREIGN KEY (`id_jabatan`) REFERENCES `jabatan` (`id_jabatan`),
  ADD CONSTRAINT `karyawan_ibfk_3` FOREIGN KEY (`id_divisi`) REFERENCES `divisi` (`id_divisi`);

--
-- Ketidakleluasaan untuk tabel `kota`
--
ALTER TABLE `kota`
  ADD CONSTRAINT `kota_ibfk_1` FOREIGN KEY (`id_provinsi`) REFERENCES `provinsi` (`id_provinsi`);

--
-- Ketidakleluasaan untuk tabel `perdin`
--
ALTER TABLE `perdin`
  ADD CONSTRAINT `perdin_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `karyawan` (`nip`),
  ADD CONSTRAINT `perdin_ibfk_2` FOREIGN KEY (`kota_asal`) REFERENCES `kota` (`id_kota`),
  ADD CONSTRAINT `perdin_ibfk_3` FOREIGN KEY (`kota_tujuan`) REFERENCES `kota` (`id_kota`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
